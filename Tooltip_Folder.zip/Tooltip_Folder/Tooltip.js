
        var jsonData = {
            "Table": [{
                "country": "BH1",
                "title": "Cross-Border Payments_V1",
                "Products":{
                    "code":{
                        "title": "Product_purpose_v1",
                        "desc": "can include writing blog posts and articles, scripts for videos and podcasts, as well as content for specific platforms, such as tweetstorms on Twitter or text posts on Reddit can include writing blog posts and articles, scripts for videos and podcasts, as well as content for specific platforms, such as tweetstorms on Twitter or text posts on Redditcan include writing blog posts and articles, scripts for videos and podcasts, as well as content for specific platforms, such as tweetstorms on Twitter or text posts on Redditcan include writing blog posts and articles, scripts for videos and podcasts, as well as content for specific platforms, such as tweetstorms on Twitter or text posts on Reddit"
                    }
                } 
            }, {
                "country": "BH2",
                "title": "Cross-Border Payments_V2",
                "Products":{
                    "code":{
                        "title": "Product_purpose_v2",
                        "desc": "can include writing blog posts and articles, scripts for videos and podcasts, as well as content for specific platforms, such as tweetstorms on Twitter or text posts on Reddit"
                    }
                } 
            }, {
                "country": "BH3",
                "title": "Cross-Border Payments_v3",
                "Products":{
                    "code":{
                        "title": "Product_purpose_v3",
                        "desc": "can include writing blog posts and articles, scripts for videos and podcasts, as well as content for specific platforms, such as tweetstorms on Twitter or text posts on Reddit"
                    }
                } 
            }, {
                "country": "BH4",
                "title": "Cross-Border Payments_v4",
                "Products":{
                    "code":{
                        "title": "Product_purpose_v4",
                        "desc": "can include writing blog posts and articles, scripts for videos and podcasts, as well as content for specific platforms, such as tweetstorms on Twitter or text posts on Reddit"
                    }
                } 
            },{
                "country": "BH5",
                "title": "Cross-Border Payments_v5",
                "Products":{
                    "code": {
                        "title": "Product_purpose_v5",
                        "desc": "can include writing blog posts and articles, scripts for videos and podcasts, as well as content for specific platforms, such as tweetstorms on Twitter or text posts on Reddit"
                    }
                } 
            }]
        };

        function getDropDown() {
            let selectOptions = document.getElementById("option");

            for (var i = 0; i < jsonData.Table.length; i++) {
                var option = document.createElement("OPTION");

                option.innerHTML = jsonData.Table[i].Products.code.title;
                option.value = jsonData.Table[i].Products.code.title;
                option.title = jsonData.Table[i].title;
                selectOptions.options.add(option);
            }
        };

        function ShowTooltip() {
            const title = document.getElementById('option').selectedOptions[0].title;
            document.getElementById('tooltip').innerHTML = "<span class='tooltiptext'>" + title + "</span>";
        };

       