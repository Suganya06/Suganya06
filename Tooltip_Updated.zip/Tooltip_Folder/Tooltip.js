
        var jsonData = {
                "country": "BH",
                "title": "Cross-Border Payments",
                "Products":{
                    "GDE":{
                        "title": "Goods sold (Exports in fob value)",
                        "desc": "All receipts for exports and re-exports between residents and nonresidents of goods regardsless of when the goods are shipped and the settlement type."
                    },
                    "GID":{
                        "title": "Goods bought (Exports in cif value)",
                        "desc": "All payments from imports between residents and nonresidents of goods regardsless of when the goods are shipped and the settlement type."
                    },
                    "STS":{
                        "title": "Sea Transport",
                        "desc": "Transportation service provided by sea of tickets, transport of goods, cargo, and other auxiliary services."
                    }
                } 
          }

        function getDropDown() {
            let selectOptions = document.getElementById("option");
            let code = jsonData.Products;
            for (var key in code) {

                var option = document.createElement("OPTION");

                option.innerHTML = code[key].title;
                option.value = code[key].title;
                option.title = code[key].desc;
                selectOptions.options.add(option);

            }
        };

        function ShowTooltip() {
            const title = document.getElementById('option').selectedOptions[0].title;
            document.getElementById('tooltip').innerHTML = "<span class='tooltiptext'>" + title + "</span>";
        };

       